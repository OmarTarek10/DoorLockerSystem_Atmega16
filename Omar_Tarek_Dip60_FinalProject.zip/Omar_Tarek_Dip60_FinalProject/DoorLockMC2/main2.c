 /******************************************************************************
 *
 * Module: main2
 *
 * File Name: main2.c
 *
 * Description: Main application layer
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/
#include "uart.h"
#include "timer.h"
#include "gpio.h"
#include "dcmotor.h"
#include "buzzer.h"
#include "eeprom.h"
#include "string.h"
#include "atmega_16_regs.h"

/******************************
 * 	DEFINITIONS				  *
 ******************************/
#define START_STATE '~'
#define ENTER_PASSWORD '&'
#define WRONG_PASSWORD '!'
#define CHANGE_PASSWORD '$'
#define BUZZ '%'
#define RENTER '^'
#define PASSWORD_SAVED '@'
#define CHOICE '('
#define CORRECT ')'
#define DOESNT_MATCH '>'
#define PASSWORD_MATCH ':'
#define ENTER_NEW_PASSWORD '?'
#define CLOSE '<'

/*global vars*/
volatile uint8 topvalue=0;
uint8 password1[16];
uint8 password2[16];
uint8 passwordflag=0;
volatile uint8 state;
volatile uint8 choice=0;
uint8 counter =0;
uint8 wrongCounter=0;
volatile uint16 timer_counter=-1;

/*******************************************************************************
� Description
       	 -The function Triggers buzzer , sends to mc1 messsage to tell tarek to stop messing around.
� Inputs:
	NONE
� Return: None
 *******************************************************************************/
void Timer_BUZZ(void){
	timer_counter++;
	if(timer_counter==0){
		BUZZ_On();
		UART_sendByte(BUZZ);
	}
	if(timer_counter==937){
		TIMER_deInit(0);
		BUZZ_Off();
		UART_sendByte(CHOICE);
		state=CHOICE;
		timer_counter=-1;
	}
}

/*******************************************************************************
� Description
       	 -The function acts as the callback function that will be called back a compare match
       	 take place and will rotate motor,send message to lcd from mc1
� Inputs:
	NONE
� Return: None
 *******************************************************************************/
void Timer_passMatch_CallBack(void){
	timer_counter++;
	if(timer_counter==0){
		DcMotor_Rotate(CLOCKWISE);

	}
	if(timer_counter==233){
		DcMotor_Rotate(STOP);
	}
	if(timer_counter==280){
		UART_sendByte(CLOSE);
		DcMotor_Rotate(ANTI_CLOCKWISE);
	}
	if(timer_counter==513){
		DcMotor_Rotate(STOP);
		TIMER_deInit(0);
		timer_counter=-1;
		UART_sendByte(CHOICE);
		state=CHOICE;
	}

}

/*******************************************************************************
� Description
       	 -The function acts as the callback function that will be called back when a compare
       	 match is there and it tells mc1 to display start message for a specific time .
� Inputs:
	NONE
� Return: None
 *******************************************************************************/
void Timer_missMatch_CallBack(void){
	timer_counter++;
	if(timer_counter==31){
		TIMER_deInit(0);
		timer_counter=-1;
		state=START_STATE;
	}

}

/*******************************************************************************
� Description
       	 -The function acts as the callback function that will be called back when a compare
       	 match is there and it tells mc1 that pass is incorrect for a specific time .
� Inputs:
	NONE
� Return: None
 *******************************************************************************/
void Timer_WrongPass_CallBack(void){
	timer_counter++;
	if(timer_counter==31){
		TIMER_deInit(0);
		UART_sendByte(CHOICE);
		timer_counter=-1;
		state=CHOICE;
	}

}

/*******************************************************************************
� Description
       	 -The function acts as the callback function that will be called back when a compare
       	 match is there and it tells mc1 to display choice after a specific time .
� Inputs:
	NONE
� Return: None
 *******************************************************************************/
void Timer_Match_CallBack(void){
	timer_counter++;
	if(timer_counter==31){
		TIMER_deInit(0);
		UART_sendByte(CHOICE);
		timer_counter=-1;
		state=CHOICE;
	}
}

void start_protocol(void){
	UART_sendByte(ENTER_PASSWORD);
	UART_recieveString(password1);
	UART_sendByte(RENTER);
	UART_recieveString(password2);
	if((strcmp(password1,password2)==0)&&(strlen(password1)==strlen(password2))){
		topvalue = (uint8)strlen(password1);
		for(counter=0;counter<topvalue;counter++){
			EEPROM_writeByte((0x0311+counter), password1[counter]);
		}
		state=PASSWORD_MATCH;
	}
	else{
		UART_sendByte(DOESNT_MATCH);
		state=DOESNT_MATCH;
	}
}

/*******************************************************************************
� Description
		-sends command to enter password and compares passwords
		if right then they are stored in eeprom is not then it setscall back that password is incorrect
� Inputs:
	NONE
� Return: None
 *******************************************************************************/
void change_protocol(void){
	UART_sendByte(ENTER_NEW_PASSWORD);
	UART_recieveString(password1);
	UART_sendByte(RENTER);
	UART_recieveString(password2);
	if((strcmp(password1,password2)==0)&&(strlen(password1)==strlen(password2))){
		topvalue = (uint8)strlen(password1);
		for(counter=0;counter<topvalue;counter++){
			EEPROM_writeByte((0x0311+counter), password1[counter]);
		}
		state=PASSWORD_MATCH;
	}
	else{
		UART_sendByte(DOESNT_MATCH);
		state=DOESNT_MATCH;
	}
}

/*******************************************************************************
� Description
       	 -the function checks passwords if matching then 1 is returned if not then 0 is returned
� Inputs:
	NONE
� Return: either 1 or zero
 *******************************************************************************/
uint8 checkPassword(void){
	UART_sendByte(ENTER_PASSWORD);
	UART_recieveString(password2);
	for(counter=0;counter<topvalue;counter++){
		EEPROM_readByte((uint16*)(0x0311+counter), password1[counter]);
	}
	if((strcmp(password1,password2)==0)&&(strlen(password1)==strlen(password2))){
		return 1;
	}
	else{
		wrongCounter++;
		return 0;
		}

	}


int main(void){
	Timer_Conf configuration={0,TIMER02_CTC,TIMER_PRE_1024,TOP_ICR,249};
	UART_Configuration uart_Configuration ={ENABLE,UART_OddParity,UART_8Bits,9600};
	TWI_Configuration twi_Configuration={0x08,DISABLE,Pre_1,0x03,DISABLE};
	UART_init(&uart_Configuration);
	TWI_init(&twi_Configuration);
	SREG_REG|=(1<<7);
	DcMotor_init();
	BUZZ_init();
	state=UART_recieveByte();
	while(1){

		switch (state){
		case START_STATE:
			start_protocol();
			break;

		case CHOICE:
			UART_sendByte(CHOICE);
			choice=UART_recieveByte();
			if(choice=='+'){
				passwordflag=checkPassword();
				if(passwordflag==1){
					state=0;
					wrongCounter=0;
					UART_sendByte(CORRECT);
					TIMER_init(&configuration);
					TIMER0_setCallBack(Timer_passMatch_CallBack);
				}
				else {
					if(wrongCounter==3){
						state=0;
						UART_sendByte(BUZZ);
						TIMER_init(&configuration);
						TIMER0_setCallBack(Timer_BUZZ);
						wrongCounter=0;
					}
					else{
						UART_sendByte(WRONG_PASSWORD);
						state=0;
						TIMER_init(&configuration);
						TIMER0_setCallBack(Timer_WrongPass_CallBack);
					}
				}
			}
			else if(choice=='-'){
				passwordflag=checkPassword();
				if(passwordflag==1){
					state=ENTER_NEW_PASSWORD;
					wrongCounter=0;
				}
				else{
					if(wrongCounter==3){
						state=0;
						UART_sendByte(BUZZ);
						TIMER_init(&configuration);
						TIMER0_setCallBack(Timer_BUZZ);
						wrongCounter=0;
					}
					else{
						UART_sendByte(WRONG_PASSWORD);
						state=0;
						TIMER_init(&configuration);
						TIMER0_setCallBack(Timer_WrongPass_CallBack);
					}
				}
			}
			break;
		case DOESNT_MATCH:
			state=0;
			UART_sendByte(DOESNT_MATCH);
			TIMER_init(&configuration);
			TIMER0_setCallBack(Timer_missMatch_CallBack);

			break;

		case PASSWORD_MATCH:
			state=0;
			UART_sendByte(PASSWORD_SAVED);
			TIMER0_setCallBack(Timer_Match_CallBack);
			TIMER_init(&configuration);
			break;
		case ENTER_NEW_PASSWORD:
			change_protocol();
			break;
		}


	}
}

