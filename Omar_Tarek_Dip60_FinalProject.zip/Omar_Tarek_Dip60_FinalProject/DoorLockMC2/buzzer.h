 /******************************************************************************
 *
 * Module: BUZZER
 *
 * File Name: buzzer.h
 *
 * Description: Driver for BUZZER
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/

#ifndef BUZZER_H_
#define BUZZER_H_

#define BUZZER_PORT PORTC_ID
#define BUZZER_PIN1 PIN6_ID
#define BUZZER_PIN2 PIN7_ID

void BUZZ_init(void);
void BUZZ_On(void);
void BUZZ_Off(void);


#endif /* BUZZER_H_ */
