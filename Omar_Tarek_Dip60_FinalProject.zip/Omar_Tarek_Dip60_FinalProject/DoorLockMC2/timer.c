 /******************************************************************************
 *
 * Module: timer
 *
 * File Name: timer.c
 *
 * Description: Timers driver for AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#include "timer.h"
#include "atmega_16_regs.h"
#include "avr/interrupt.h"

/**********************************************************
 * 			Functions Set in Callbacks					  *
 *********************************************************/
/*call back for timer 0*/
static volatile void (*g_callBackTimer0)(void)=NULL_PTR;

/*call back for timer 1*/
static volatile void (*g_callBackTimer1)(void)=NULL_PTR;

/*call back for timer 2*/
static volatile void (*g_callBackTimer2)(void)=NULL_PTR;


/**********************************************************************************
 * 						ISR's
 *********************************************************************************/

/********************************************************
 *	 					TIMER0							*
 *******************************************************/

/* ISR for Overflow of Timer 0*/
ISR(TIMER0_OVF_vect){
	if(NULL_PTR!=g_callBackTimer0)
	(*g_callBackTimer0)();
}

/* ISR for Compare of Timer 0*/
ISR(TIMER0_COMP_vect){
	if(NULL_PTR!=g_callBackTimer0)
	(*g_callBackTimer0)();
}

/********************************************************
 *	 					TIMER1							*
 *******************************************************/

/* ISR for Compare A of Timer 1*/
ISR(TIMER1_COMPA_vect){
	if(NULL_PTR!=g_callBackTimer1)
	(*g_callBackTimer1)();
}

/* ISR for Compare B of Timer 1*/
ISR(TIMER1_COMPB_vect){
	if(NULL_PTR!=g_callBackTimer1)
	(*g_callBackTimer1)();
}

/* ISR for Overflow of Timer 1*/
ISR(TIMER1_OVF_vect){
	if(NULL_PTR!=g_callBackTimer1)
	(*g_callBackTimer1)();
}

/********************************************************
 *	 					TIMER2							*
 *******************************************************/
/* ISR for Overflow of Timer 2*/
ISR(TIMER2_OVF_vect){
	if(NULL_PTR!=g_callBackTimer2)
	(*g_callBackTimer2)();
}

/* ISR for Compare of Timer 2*/
ISR(TIMER2_COMP_vect){
	if(NULL_PTR!=g_callBackTimer2)
	(*g_callBackTimer2)();
}


/*******************************************************************************
� Description
       -Set timer registers according to the working mode choosen
       -choose which timer to use
       -enable interrupt according to the working mode
� Inputs:
		 -s_configuration: pointer to structure Timer_Conf to choose the wanted
		 	 	 	  timer ,prescaler ,working mode
� Return: None

 *******************************************************************************/
void TIMER_init(Timer_Conf *s_configuration){
	switch(s_configuration->TIMER_NO){
	case 0:
#ifdef TIMER0_INTERRUPT_COMP_EN
			TIMSK_REG|=(0x02);
#endif

#ifdef TIMER0_INTERRUPT_OVR_EN
			TIMSK_REG|=(0x01);
#endif
		TCNT0_REG=0;
		TCCR0_REG=(s_configuration->ModeOperation)|(s_configuration->Prescaler);
		OCR0_REG=(s_configuration->CTC_VALUE);

		break;
/*******************************************************************************/
	case 1:
		TCNT1_REG=0;
		TCCR1A_REG=(s_configuration->ModeOperation);
		if((s_configuration->ModeOperation)!=(TIMER1_NORMAL)){
			TCCR1B_REG=(s_configuration->Prescaler)|(s_configuration->Type);
			if((s_configuration->Type)==TOP_OCR){
				OCR1B_REG=(s_configuration->CTC_VALUE);
				OCR1A_REG=(s_configuration->Top);

			}
			else{
				OCR1B_REG=(s_configuration->CTC_VALUE);
				OCR1A_REG=(s_configuration->CTC_VALUE);
				ICR1_REG=(s_configuration->Top);
			}
		}
		else{
		TCCR1B_REG=(s_configuration->Prescaler);
		}
#ifdef TIMER1_INTERRUPT_COMP_EN
				TIMSK_REG|=(0x18);
#endif

#ifdef TIMER1_INTERRUPT_OVR_EN
				TIMSK_REG|=(0x04);
#endif
		break;
/*******************************************************************************/
	case 2:
		TCNT2_REG=0;
		TCCR2_REG=(s_configuration->ModeOperation)|(s_configuration->Prescaler);
		OCR2_REG=(s_configuration->CTC_VALUE);
#ifdef TIMER2_INTERRUPT_COMP_EN
		TIMSK_REG|=(0x80);
#endif

#ifdef TIMER2_INTERRUPT_OVR_EN
		TIMSK_REG|=(0x40);
#endif
		break;
	}
}

/*******************************************************************************
� Description
       -clear Tcnt register value
       -choose which timer to clear
� Inputs:
		 -a_timerNo: choose which timer to clear
� Return: None

 *******************************************************************************/
void TIMER_clear(uint8 a_timerNo){
	switch(a_timerNo){
	case 0:
		TCNT0_REG=0;
		break;
	case 1:
		TCNT1_REG=0;
		break;
	case 2:
		TCNT2_REG=0;
		break;
	}
}

/*******************************************************************************
� Description
       -stop timer from working according to the choosen timer no
       -return every register to it's initial value
� Inputs:
		 -a_timerNo :set which timer to stop
� Return: None

 *******************************************************************************/
void TIMER_deInit(uint8 a_timerNo){
	switch(a_timerNo){
	case 0:
		TCCR0_REG=0;
		TIMSK_REG&=(0xFC);
		break;
	case 1:
		TCCR1A_REG=0;
		TCCR1B_REG=0;
		TIMSK_REG&=(0xE3);
		break;
	case 2:
		TCCR2=0;
		TIMSK_REG&=(0x3F);
		break;
	}
}

/*************************************************************
 * 					CallBacks Setting						 *
 ************************************************************/
void TIMER0_setCallBack(void (*a_ptr_timer0)(void)){
	g_callBackTimer0=a_ptr_timer0;
}

void TIMER1_setCallBack(void (*a_ptr_timer1)(void)){
	g_callBackTimer1=a_ptr_timer1;
}

void TIMER2_setCallBack(void (*a_ptr_timer2)(void)){
	g_callBackTimer2=a_ptr_timer2;
}


/*******************************************************************************
� Description
       -get current tcnt value
       -choose which timer to return the tcnt value of it
� Inputs:
		 -a_timerNo: which timer to return its register value
� Return: tcnt value of the choosen timer

 *******************************************************************************/
uint16 TIMER_getTcntValue(uint8 a_timerNo){
	uint16 tcntvalue=0;
	switch(a_timerNo){
	case 0:
		tcntvalue=TCNT0_REG;
		break;
	case 1:
		tcntvalue=TCNT1_REG;
		break;
	case 2:
		tcntvalue=TCNT2_REG;
		break;
	}
	return tcntvalue;
}

/*******************************************************************************
� Description
       -Modify top compare value to timer 1
� Inputs:
		 -top: set icr1 value to be used as top in case of CTC mode with
		 icr1 as top.
� Return: None

 *******************************************************************************/
void TIMER_SetIcr1Value(uint16 top){
	ICR1_REG=top;
}
