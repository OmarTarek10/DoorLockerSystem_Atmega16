 /******************************************************************************
 *
 * Module: BUZZER
 *
 * File Name: buzzer.c
 *
 * Description: Driver for BUZZER
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/

#include "buzzer.h"
#include "gpio.h"

/*******************************************************************************
� Description
       	 -Sets pins of buzzer
� Inputs:
		-
� Return: None
 *******************************************************************************/
void BUZZ_init(void){
	GPIO_setupPinDirection(BUZZER_PORT, BUZZER_PIN1, PIN_OUTPUT);
	GPIO_setupPinDirection(BUZZER_PORT, BUZZER_PIN2, PIN_OUTPUT);
}

void BUZZ_On(void){
	GPIO_writePin(BUZZER_PORT, BUZZER_PIN1, LOGIC_HIGH);
	GPIO_writePin(BUZZER_PORT, BUZZER_PIN2, LOGIC_LOW);
}

void BUZZ_Off(void){
	GPIO_writePin(BUZZER_PORT, BUZZER_PIN1, LOGIC_LOW);
	GPIO_writePin(BUZZER_PORT, BUZZER_PIN2, LOGIC_LOW);
}
