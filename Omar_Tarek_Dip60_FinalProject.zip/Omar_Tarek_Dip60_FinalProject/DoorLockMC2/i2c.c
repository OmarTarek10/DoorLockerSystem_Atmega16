 /******************************************************************************
 *
 * Module: I2C
 *
 * File Name: i2c.c
 *
 * Description: Simple Driver for I2C
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#include "atmega_16_regs.h"
#include "i2c.h"
#include "common_macros.h"

/*******************************************************************************
� Description
       	 -Initialise the I2C with the desired configurations which are the slave
       	  address and the Bit rate
� Inputs:
		 -configs: pointer to structure containing all the configurations needed
� Return: None
 *******************************************************************************/
void TWI_init(TWI_Configuration *s_configuration){
	uint8 Master_address;
	Master_address=(s_configuration->TWI_SlaveAdress);
	Master_address&=0xfe;
		TWBR_REG=(s_configuration->TWI_TwbrRegValue);
		TWSR_REG =(s_configuration->TWI_Pre);
		SET_BIT(TWCR_REG,TWEN_REG);
		if((s_configuration->TWI_InterruptEn)==ENABLE){
			SET_BIT(TWCR_REG,TWIE_REG);
		}
		TWAR_REG=Master_address;
		TWAR_REG|=(s_configuration->GeneralCallEn);
}

/*******************************************************************************
� Description
       	 -Send the start Bit and wait until it is sent
� Inputs: None
� Return: None
 *******************************************************************************/
void TWI_start(void){
	TWCR_REG=(1<<TWEN_REG)|(1<<TWSTA_REG)|(1<<TWINT_REG);
	while(BIT_IS_CLEAR(TWCR_REG,TWINT_REG));
}

/*******************************************************************************
� Description
       	 -Send stop bit
� Inputs: None
� Return: None
 *******************************************************************************/
void TWI_stop(void){
	TWCR_REG=(1<<TWEN_REG)|(1<<TWSTO_REG)|(1<<TWINT_REG);

}


/*******************************************************************************
� Description
       	 -Send byte and wait until it is sent
� Inputs:
		 -a_byte: byte to be sent
� Return: None
 *******************************************************************************/
void TWI_write(uint8 a_data){
	TWDR_REG=a_data;
	TWCR_REG=(1<<TWINT_REG)|(1<<TWEN_REG);
	while(BIT_IS_CLEAR(TWCR_REG,TWINT_REG));
}

/*******************************************************************************
� Description
       	-Read data and then send an ACK
� Inputs: None
� Return:
		-Received byte
 *******************************************************************************/
uint8 TWI_recieveWithAck(void){
	TWCR_REG=(1<<TWEN_REG)|(1<<TWINT_REG)|(1<<TWEA_REG);
	while(BIT_IS_CLEAR(TWCR_REG,TWINT_REG));
	TWCR_REG|=(1<<TWEA_REG);
	return TWDR_REG;
}

/*******************************************************************************
� Description
       	-Read data and then send a negative ACK
� Inputs: None
� Return:
		-Received byte
 *******************************************************************************/
uint8 TWI_recieveWithNACK(void){
	TWCR_REG=(1<<TWEN_REG)|(1<<TWINT_REG);
	while(BIT_IS_CLEAR(TWCR_REG,TWINT_REG));
	return TWDR_REG;
}

/*******************************************************************************
� Description
       	-Get the current status of the I2C
� Inputs: None
� Return:
		-Status
 *******************************************************************************/
uint8 TWI_getStatus(void){
    uint8 status;
    /* masking to eliminate first 3 bits and get the last 5 bits (status bits) */
    status = TWSR_REG & 0xF8;
    return status;
}
