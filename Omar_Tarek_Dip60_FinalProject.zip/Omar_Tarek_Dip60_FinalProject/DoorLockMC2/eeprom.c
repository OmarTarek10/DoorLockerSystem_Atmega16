 /******************************************************************************
 *
 * Module: EEPROM
 *
 * File Name: eeprom.c
 *
 * Description: Driver for external EEPROM
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/
#include "eeprom.h"

/*******************************************************************************
� Description
       	 -The function communicate with the I2C driver to write a byte in a certain
       	  address in the external EEPROM.
� Inputs:
		-address: Address in the EEPROM to store the byte
		-data: The byte required to be stored
� Return: None
 *******************************************************************************/
uint8 EEPROM_writeByte(uint16 slaveAddress,uint8 byte){
	uint8 slavemod=0xA0;
	slavemod=slavemod|((slaveAddress&0x0700)>>7);

	TWI_start();
	if(TWI_getStatus()!=TWI_START){
		return 'w';
	}

	TWI_write(slavemod);
	if(TWI_getStatus()!=TWI_MT_SLA_W_ACK){
		return 'w';
	}

	slavemod=(uint8)(slaveAddress);
	TWI_write(slavemod);
	if(TWI_getStatus()!=TWI_MT_DATA_ACK){
		return 'w';
	}

	TWI_write(byte);
	if(TWI_getStatus()!=TWI_MT_DATA_ACK){
		return 'w';
	}


	TWI_stop();
	return 1;
}

/*******************************************************************************
� Description
       	 -The function communicate with the I2C driver to read a byte from a certain
       	  address in the external EEPROM.
� Inputs:
		-address: Address in the EEPROM to read the byte from
� Return:
		The byte read from the EEPROM
 *******************************************************************************/
uint8 EEPROM_readByte(uint16 slaveAddress,uint8 *dataRecieved){
	uint8 slavemod=0xA0;
	slavemod=slavemod|((slaveAddress&0x0700)>>7);

	TWI_start();
	if(TWI_getStatus()!=TWI_START){
		return 'w';
	}

	TWI_write(slavemod);
	if(TWI_getStatus()!=TWI_MT_SLA_W_ACK){
		return 'w';
	}

	slavemod=(uint8)(slaveAddress);
	TWI_write(slavemod);
	if(TWI_getStatus()!=TWI_MT_DATA_ACK){
		return 'w';
	}

	    /* Send the Repeated Start Bit */
	    TWI_start();
	    if (TWI_getStatus() != TWI_REP_START)
	        return 'w';

	    /* Send the device address, we need to get A8 A9 A10 address bits from the
	     * memory location address and R/W=1 (Read) */
	    TWI_write((uint8)((0xA0) | ((slaveAddress & 0x0700)>>7) | 1));
	    if (TWI_getStatus() != TWI_MT_SLA_R_ACK)
	        return 'w';

	    /* Read Byte from Memory without send ACK */
	    *dataRecieved = TWI_recieveWithNACK();
	    if (TWI_getStatus() != TWI_MR_DATA_NACK)
	        return 'w';
    /* Send the Stop Bit */
    TWI_stop();

    return 1;
}

/*
uint8 EEPROM_writeMatrix(uint8 *first,uint8 size,uint16 slaveAddress){
	uint8 counter;

	uint8 slavemod=0xA0;
	slavemod=slavemod|((slaveAddress&0x0700)>>7);

	TWI_start();
	if(TWI_getStatus()!=TWI_START){
		return 'w';
	}

	TWI_write(slavemod);
	if(TWI_getStatus()!=TWI_MT_SLA_W_ACK){
		return 'w';
	}

	slavemod=(uint8)(slaveAddress);
	TWI_write(slavemod);
	if(TWI_getStatus()!=TWI_MT_DATA_ACK){
		return 'w';
	}

	for(counter=0;counter<size;counter++){

		TWI_write(*(first+counter));
		if(TWI_getStatus()!=TWI_MT_DATA_ACK){
			return 'w';
		}
	}

	TWI_stop();
	return 1;
}

*/
