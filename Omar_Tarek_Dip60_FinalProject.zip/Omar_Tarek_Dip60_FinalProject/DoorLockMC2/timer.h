 /******************************************************************************
 *
 * Module: timer
 *
 * File Name: timer.h
 *
 * Description: Timers driver for AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/
#ifndef TIMER_H_
#define TIMER_H_
#include "std_types.h"
/*===============================================================================*/
/*definitions*/
#define TIMER0_INTERRUPT_COMP_EN
//#define TIMER0_INTERRUPT_OVR_EN
#define TIMER1_INTERRUPT_COMP_EN
#define TIMER1_INTERRUPT_OVR_EN
#define TIMER2_INTERRUPT_COMP_EN
//#define TIMER2_INTERRUPT_OVR_EN

/*******************************
* 		    NEW_TYPES 		   *
*******************************/

/*IN ORDER TO SET DIRECTLY THE PRESCALER AND TURN ON THE FOCO1A,FOC1B REGS*/
typedef enum {
	TIMER_PRE_0=0x00,TIMER_PRE_1=0x01,TIMER_PRE_8=0x02,\
	TIMER_PRE_64=0x03,TIMER_PRE_256=0x04,TIMER_PRE_1024=0x05
} TIMER_PRESCALER;

typedef enum {
	TIMER02_NORMAL=0x80,TIMER02_CTC=0x88,TIMER02_TOGGLE_CTC=0x98,TIMER02_CLEAR_CTC=0xA8,\
	TIMER1_NORMAL=0x0C,TIMER1_CTCA=0x0C,TIMER1_TOGGLE_CTCA=0x4C,TIMER1_CLEAR_CTCA=0x8C,\
	TIMER1_CTCB=0x0C,TIMER1_TOGGLE_CTCB=0x1C,TIMER1_CLEAR_CTCB=0x2C
}TIMER_TCCR_MODE;

typedef enum {
	TOP_OCR=0x08,TOP_ICR=0x18
}TIMER1_CTC_TYPE;

typedef struct{
	uint8 TIMER_NO;
	TIMER_TCCR_MODE ModeOperation;
	TIMER_PRESCALER Prescaler;
	TIMER1_CTC_TYPE Type;
	uint16 CTC_VALUE;
	uint16 Top;
}Timer_Conf;
/* * * * * * * * *  * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * -Struct that contains which timer to use
 * -Mode of operation
 * -prescaler
 * -Type of compare mode
 * -CTC compare value
 * -top value in case of timer1
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*===============================================================================*/
/****************************************************
 * 				FUNCTIONS							*
 ***************************************************/

/*******************************************************************************
� Description
       -Set timer registers according to the working mode choosen
       -choose which timer to use
       -enable interrupt according to the working mode
� Inputs:
		 -s_configuration: pointer to structure Timer_Conf to choose the wanted
		 	 	 	  timer ,prescaler ,working mode
� Return: None

 *******************************************************************************/
void TIMER_init(Timer_Conf *s_configuration);

/*******************************************************************************
� Description
       -clear Tcnt register value
       -choose which timer to clear
� Inputs:
		 -a_timerNo: choose which timer to clear
� Return: None

 *******************************************************************************/
void TIMER_clear(uint8 a_timerNo);

/*******************************************************************************
� Description
       -stop timer from working according to the choosen timer no
       -return every register to it's initial value
� Inputs:
		 -a_timerNo :set which timer to stop
� Return: None

 *******************************************************************************/
void TIMER_deInit(uint8 a_timerNo);

/*******************************************************************************
� Description
       -Modify top compare value to timer 1
� Inputs:
		 -top: set icr1 value to be used as top in case of CTC mode with
		 icr1 as top.
� Return: None

 *******************************************************************************/
void TIMER_SetIcr1Value(uint16 top);
/*********************************************************************
 * 							CALL BACKS								 *
 ********************************************************************/
/*CALLBACK FUNCTION IN ORDER TO EXECUTE ISR*/
void TIMER0_setCallBack(void (*a_ptr)(void));
void TIMER1_setCallBack(void (*a_ptr)(void));
void TIMER2_setCallBack(void (*a_ptr)(void));

/*****************************************************************************/

/*******************************************************************************
� Description
       -get current tcnt value
       -choose which timer to return the tcnt value of it
� Inputs:
		 -a_timerNo: which timer to return its register value
� Return: tcnt value of the choosen timer

 *******************************************************************************/
uint16 TIMER_getTcntValue (uint8 a_timerNo);



#endif /* TIMER_H_ */
