 /******************************************************************************
 *
 * Module: DCMOTOR
 *
 * File Name: dcmotor.h
 *
 * Description: DC MOTOR DRIVER FOR AVR
 *
 * Author: OMAR TAREK
 *
 *******************************************************************************/

#ifndef DCMOTOR_H_
#define DCMOTOR_H_

#include "std_types.h"
#define DCMOTOR_PIN1 PIN4_ID
#define DCMOTOR_PIN2 PIN3_ID
#define DCMOTOR_SPEED_PIN PIN5_ID
#define DCMOTOR_PORT PORTD_ID
/*
#define DCMOTOR_SPEED_CONTROL_EN
*/

/*
 * in order to detect which direction should motor rotate.
 */
typedef enum {
	CLOCKWISE=0,ANTI_CLOCKWISE=1,STOP=2
}DcMotor_State;

void DcMotor_init(void);
#ifdef DCMOTOR_SPEED_CONTROL_EN
void DcMotor_Rotate(DcMotor_State state,uint8 speed);
#else
void DcMotor_Rotate(DcMotor_State state);
#endif




#endif /* DCMOTOR_H_ */
