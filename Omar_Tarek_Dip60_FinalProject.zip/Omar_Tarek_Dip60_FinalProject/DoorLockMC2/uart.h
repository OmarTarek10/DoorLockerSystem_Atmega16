 /******************************************************************************
 *
 * Module: UART
 *
 * File Name: uart.h
 *
 * Description: Source file for the UART AVR driver
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/
#ifndef UART_H_
#define UART_H_
#include "std_types.h"

/*#define SYNC*/

/*UCSRA*/
#define UART_RecieveComplete 7
#define UART_TransmitComplete 6
#define UART_DataRegisterEmpty 5
#define UART_FRAMEERROR 4
#define UART_DATAOVERRUN 3
#define UART_PARITYERROR 2
#define UART_U2X 1
#define UART_MULTIPROCESSORCOMM 0

/*UCSRB*/
#define UART_RXInterruptEn 7
#define UART_TXInterruptEn 6
#define UART_DataRegisterEmpty 5
#define UART_ReceiverEn 4
#define UART_TransmitterEn 3

/*UCSRC*/
#define URSEL 7


#define RXCIE 7
#define TXCIE 6
#define UDRIE 5

#define UART_RECIEVE_READY 0x22
/*#define UART_SEND_INTERRUPT*/
/*#define UART_RECIEVE_INTERRUPT*/
/***************************************
 *       	USER DEFINED TYPES         *
***************************************/


typedef enum{
	UART_Sync=0x40,UART_Async=0x00
}UART_UCSRC_Workingmode;

typedef enum {
	UART_NoParity=0x00,UART_EvenParity=0x20,UART_OddParity=0x30
}UART_UCSRC_parity;



typedef enum{
	UART_1Bit=0x00,UART_2Bits=0x80
}UART_UCSRC_StopBits;

typedef enum{
	UART_5Bits=0x00,UART_6Bits=0x02,UART_7Bits=0x04,UART_8Bits=0x06
}UART_UCSRC_DataBits;

#ifdef SYNC
typedef enum{
	UART_ReceiveFalling=0x00,UART_ReceiveRising=0x01
}UART_UCSRC_Clockedge;
#endif

typedef struct {
	uint8 FreqMULT_UCSRA_EN;
#ifdef SYNC
	UART_UCSRC_Workingmode mode;
#endif
	UART_UCSRC_parity Paritybits;
	UART_UCSRC_DataBits enablebits;
	uint32 baudrate;
#ifdef SYNC
	UART_UCSRC_Clockedge EdgeType;
#endif
}UART_Configuration;
/*********************************************************
 * Struct that contains:
 * -Enable of Frequency multiplier
 * -enable of parity check
 * -Synchronus uart enable
 * -set register values according to the working mode
 * -set baud rate.
 ************************************************************/

/******************************************************************
 * 						FUNCTION DEFINITIONS
 *****************************************************************/
/*
 * Description :
 * Functional responsible for Initialize the UART device by:
 * 1. Setup the Frame format like number of data bits, parity bit type and number of stop bits.
 * 2. Enable the UART.
 * 3. Setup the UART baud rate.
 * -all the previous is done using the configuration struct of uart
 */
void UART_init(const UART_Configuration *s_Configuration);

/* * * * * * * * ** * *  ** * * * *  * ** *  ** * * * * * * * *
* Description :
* Functional responsible for send byte to another UART device.
*
* -inputs a_data :data byte to be sent.
*
* Sends data and wait using polling or interrupts according to defines
* * * * * * * * * * * * * * * * * * * * *** * * * * * * * * * * */
void UART_sendByte(const uint8 a_data);

/*
 * Description :
 * Functional responsible for receive byte from another UART device.
 * -uses polling when recieving
 * -returns recieved byte.
 */
uint8 UART_recieveByte(void);

/*******************************************************************
 * Stop UART FROM WORKING
 ******************************************************************/
void UART_Stop(void);

/* ** * *  ** * * *  * * * * * * ** * * * * * * * * * * * * * * * * * * * * * * * *
 * Description :
 * modify baud rate of the uart of the device that uses this func.
 *
 * ----NOTE THAT BAUD RATE MUST BE MODIFIED IN BOTH UART SEND RECIEVE DEVICES--------
 * * * * * * * * * ** * * * * * * * * * * * *  * ** * * * * * * * * * *  ** * * * */
void UART_ModifyBaudRate(const uint32 a_BaudRate);

/*
 * Description :
 * Send the required string through UART to the other UART device.
 */
void UART_sendString(const uint8* a_data);

/* * * * * * * * * *  * * * * * *  * * *
 * Description :
 * returns recieved data byte
 * Return: Byte recieved
 * * * * * *  * * * * * *  * * * * * * */
uint8 UART_getRecUartBuffer(void);
void UART_recieveString(uint8* a_data);

#endif /* UART_H_ */
