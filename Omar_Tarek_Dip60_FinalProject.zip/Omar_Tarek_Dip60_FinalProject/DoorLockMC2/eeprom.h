 /******************************************************************************
 *
 * Module: EEPROM
 *
 * File Name: eeprom.h
 *
 * Description: Driver for external EEPROM
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/

#ifndef EEPROM_H_
#define EEPROM_H_

#include "std_types.h"
#include "i2c.h"

/*******************************************************************************
� Description
       	 -The function communicate with the I2C driver to write a byte in a certain
       	  address in the external EEPROM.
� Inputs:
		-address: Address in the EEPROM to store the byte
		-data: The byte required to be stored
� Return: None
 *******************************************************************************/
uint8 EEPROM_writeByte(uint16 slaveAddress,uint8 byte);

/*******************************************************************************
� Description
       	 -The function communicate with the I2C driver to read a byte from a certain
       	  address in the external EEPROM.
� Inputs:
		-address: Address in the EEPROM to read the byte from
� Return:
		The byte read from the EEPROM
 *******************************************************************************/
uint8 EEPROM_readByte(uint16 slaveAddress,uint8 *dataRecieved);


#endif /* EEPROM_H_ */
