 /******************************************************************************
 *
 * Module: I2C
 *
 * File Name: i2C.h
 *
 * Description: I2C driver
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/
#ifndef I2C_H_
#define I2C_H_
#include "std_types.h"

/*******************************************************************************
 *                      Preprocessor Macros                                    *
 *******************************************************************************/

/* I2C Status Bits in the TWSR Register */
#define TWI_START         0x08 /* start has been sent */
#define TWI_REP_START     0x10 /* repeated start */
#define TWI_MT_SLA_W_ACK  0x18 /* Master transmit ( slave address + Write request ) to slave + ACK received from slave. */
#define TWI_MT_SLA_R_ACK  0x40 /* Master transmit ( slave address + Read request ) to slave + ACK received from slave. */
#define TWI_MT_DATA_ACK   0x28 /* Master transmit data and ACK has been received from Slave. */
#define TWI_MR_DATA_ACK   0x50 /* Master received data and send ACK to slave. */
#define TWI_MR_DATA_NACK  0x58 /* Master received data but doesn't send ACK to slave. */

#define TWI_COLL_FLAG_REG 3
/*#define I2C_INTERRUPT_EN*/
#define TWINT_REG 7
#define TWEA_REG 6
#define TWSTA_REG 5
#define TWSTO_REG 4
#define TWWC_REG 3
#define TWEN_REG 2
#define TWIE_REG 0


#define TWGCE_REG 0

typedef enum{
	Pre_1=0x00,Pre_4=0x01,Pre_16=0x02,Pre_64=0x03
}TWI_PreScaler;

typedef struct{
	uint8 TWI_TwbrRegValue;
	uint8 TWI_InterruptEn;
	TWI_PreScaler TWI_Pre;
	uint8 TWI_SlaveAdress;
	uint8 GeneralCallEn;

}TWI_Configuration;

/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/

/*******************************************************************************
� Description
       	 -Initialise the I2C with the desired configurations which are the slave
       	  address and the Bit rate
� Inputs:
		 -configs: pointer to structure containing all the configurations needed
� Return: None
 *******************************************************************************/
void TWI_init(TWI_Configuration *s_configuration);

/*******************************************************************************
� Description
       	 -Send the start Bit and wait until it is sent
� Inputs: None
� Return: None
 *******************************************************************************/
void TWI_start(void);

/*******************************************************************************
� Description
       	 -Send stop bit
� Inputs: None
� Return: None
 *******************************************************************************/
void TWI_stop(void);

/*******************************************************************************
� Description
       	 -Send byte and wait until it is sent
� Inputs:
		 -a_byte: byte to be sent
� Return: None
 *******************************************************************************/
void TWI_write(uint8 data);

/*******************************************************************************
� Description
       	-Read data and then send an ACK
� Inputs: None
� Return:
		-Received byte
 *******************************************************************************/
uint8 TWI_recieveWithAck(void);

/*******************************************************************************
� Description
       	-Get the current status of the I2C
� Inputs: None
� Return:
		-Status
 *******************************************************************************/
uint8 TWI_recieveWithNACK(void);

/*******************************************************************************
� Description
       	-Get the current status of the I2C
� Inputs: None
� Return:
		-Status
 *******************************************************************************/
uint8 TWI_getStatus(void);


#endif /* I2C_H_ */
