 /******************************************************************************
 *
 * Module: UART
 *
 * File Name: uart.c
 *
 * Description: Source file for the UART AVR driver
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/
#include "uart.h"
#include "atmega_16_regs.h"
#include "common_macros.h"
#include "avr/interrupt.h"


/*====================================================================*/

#ifdef UART_SEND_INTERRUPT
static volatile uint8 data_to_Send;
static volatile uint8 g_sentFlag = FALSE;

ISR(USART_UDRE_vect){

	if(g_sentFlag==TRUE)
		UDR_REG=data_to_send;
		g_sentFlag=false;
}
#endif

/*====================================================================*/


#ifdef UART_RECIEVE_INTERRUPT
static volatile void (*g_RecieveCallBackFunc)(void)=NULL_PTR;
ISR(USART_RXC_vect){
if(NULL_PTR!=g_RecieveCallBackFunc &&BIT_IS_CLEAR(UCSRA_REG, UART_FRAMEERROR) && BIT_IS_CLEAR(UCSRA_REG, UART_PARITYERROR)){
		g_RecieveCallBackFunc();
	}
}
#endif


/*====================================================================*/


/*====================================================================*/


/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/
/*
 * Description :
 * Functional responsible for Initialize the UART device by:
 * 1. Setup the Frame format like number of data bits, parity bit type and number of stop bits.
 * 2. Enable the UART.
 * 3. Setup the UART baud rate.
 * -all the previous is done using the configuration struct of uart
 */
void UART_init(const UART_Configuration *s_Configuration){
	uint32 baudRate;
	uint16 ubrr_value=0;
	baudRate=(s_Configuration->baudrate);
	UCSRA_REG=((s_Configuration->FreqMULT_UCSRA_EN)<<UART_U2X);

	UCSRB_REG=SET_BIT(UCSRB_REG,UART_TransmitterEn);
	UCSRB_REG=SET_BIT(UCSRB_REG,UART_ReceiverEn);

#ifdef UART_SEND_INTERRUPT
	SET_BIT(UCSRB_REG,UDRIE );
#endif
#ifdef UART_RECIEVE_INTERRUPT
	SET_BIT(UCSRB_REG, RXCIE);
#endif

#ifdef SYNC
	UCSRC_REG=(s_Configuration->Paritybits)|(s_Configuration->enablebits)|(s_Configuration->mode)|(s_Configuration->EdgeType);
#else
	UCSRC_REG=(s_Configuration->Paritybits)|(s_Configuration->enablebits)|(1<<URSEL);
#endif


	ubrr_value = (uint16)(((F_CPU / (baudRate * 8UL))) - 1);
	UBRRH_REG=(uint8)(ubrr_value>>8);
	UBRRL_REG=(uint8)(ubrr_value);
}


/* * * * * * * * ** * *  ** * * * *  * ** *  ** * * * * * * * *
* Description :
* Functional responsible for send byte to another UART device.
*
* -inputs a_data :data byte to be sent.
*
* Sends data and wait using polling until sending is done
* * * * * * * * * * * * * * * * * * * * *** * * * * * * * * * * */
#ifndef UART_SEND_INTERRUPT
void UART_sendByte(const uint8 a_data){
	while(BIT_IS_CLEAR(UCSRA_REG,UART_DataRegisterEmpty));
	UDR_REG=a_data;
}
#endif

/* * * * * * * * ** * *  ** * * * *  * ** *  ** * * * * * * * *
* Description :
* Functional responsible for send byte to another UART device.
*
* -inputs a_data :data byte to be sent.
*
* Sends data when interrupted
* * * * * * * * * * * * * * * * * * * * *** * * * * * * * * * * */
#ifdef UART_SEND_INTERRUPT
void UART_SendByte(uint8 a_data){
	data_to_Send=a_data;
	g_sentFlag = TRUE;
}
#endif

/*
 * Description :
 * Functional responsible for receive byte from another UART device.
 * -uses polling when recieving
 * -returns recieved byte.
 */
#ifndef UART_RECIEVE_INTERRUPT
uint8 UART_recieveByte(void){
	while(BIT_IS_CLEAR(UCSRA_REG,UART_RecieveComplete));
	if(BIT_IS_CLEAR(UCSRA_REG, FE) && BIT_IS_CLEAR(UCSRA, PE)){
		return UDR_REG;
	}
	else{
		return 0xff;
	}
}
#endif

/* * * * * *  * * * *  * * * *  * * *  * * * *  * * * * *  * * * * * * * *  * *
 * Description :
 * Functional responsible for receive byte from another UART device.
 * -works with interrupts ,when a byte is recieved an interrupt is triggered.
 * Returns none therefore a callback func must be used
 * * * * * * * * * * * * * **  * **  * * ** * * * * *  * * * * * *  * * * *  * */
#ifdef UART_RECIEVE_INTERRUPT
void UART_SetCallBack_recieveByte(void (*a_ptr1)(void)){
	g_RecieveCallBackFunc=a_ptr1;

}
#endif



/*
 * Description :
 * Send the required string through UART to the other UART device.
 */
void UART_sendString(const uint8* a_string){
	while (*(a_string)!='\0'){
		UART_sendByte(*(a_string));
		a_string++;
	}
	UART_sendByte('#');
}

#ifndef UART_RECIEVE_INTERRUPT
void UART_recieveString(uint8 *Str){
	uint8 i = 0;

	/* Receive the first byte */
	Str[i] = UART_recieveByte();

	/* Receive the whole string until the '#' */
	while(Str[i] != '#')
	{
		i++;
		Str[i] = UART_recieveByte();
	}
	Str[i]='\0';
}
#endif


/* ** * *  ** * * *  * * * * * * ** * * * * * * * * * * * * * * * * * * * * * * * *
 * Description :
 * modify baud rate of the uart of the device that uses this func.
 *
 * ----NOTE THAT BAUD RATE MUST BE MODIFIED IN BOTH UART SEND RECIEVE DEVICES--------
 * * * * * * * * * ** * * * * * * * * * * * *  * ** * * * * * * * * * *  ** * * * */
void UART_ModifyBaudRate(const uint32 a_BaudRate){
	uint16 ubrr_value=0;
	ubrr_value = (uint16)(F_CPU / ((a_BaudRate) * 8UL) - 1);
	UBRRL_REG=(uint8)ubrr_value;
	UBRRH_REG=(uint8)(ubrr_value>>8);
}


/* * * * * * * * * *  * * * * * *  * * *
 * Description :
 * returns recieved data byte
 * Return: Byte recieved
 * * * * * *  * * * * * *  * * * * * * */
uint8 UART_getRecUartBuffer(void){
	if(BIT_IS_SET(UCSRA, RXC)){
		return UDR_REG;
	}
	else{
		return 0xFF;
	}
}


/*******************************************************************
 * Stop UART FROM WORKING
 ******************************************************************/
void UART_Stop(void){
	UCSRA_REG=0;
	UCSRB_REG=0;
	UCSRC_REG=0;
}

