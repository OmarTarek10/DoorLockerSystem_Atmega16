 /******************************************************************************
 *
 * Module: main
 *
 * File Name: main.c
 *
 * Description: Main application layer
 *
 * Author: Omar Tarek
 *
 *******************************************************************************/

#include "keypad.h"
#include "gpio.h"
#include "lcd.h"
#include "uart.h"
#include "util/delay.h"
#include <string.h>

/*
 DEFINITIONS
 */
#define START_STATE '~'
#define ENTER_PASSWORD '&'
#define WRONG_PASSWORD '!'
#define CHANGE_PASSWORD '$'
#define BUZZ '%'
#define RENTER '^'
#define PASSWORD_SAVED '@'
#define CHOICE '('
#define CORRECT ')'
#define DOESNT_MATCH '>'
#define PASSWORD_MATCH ':'
#define ENTER_NEW_PASSWORD '?'
#define CLOSE '<'
/***********************************************************/
/*GLOBAL VARS*/
uint8 key[16];
uint8 counter=0;

uint8 choice=0;
//volatile uint16 timer_counter=0;
volatile uint8 response=0;

/*******************************************************************************
� Description
       	 -The function acts as the callback function that will be called back when the
       	 recieve interrupt is triggered.
� Inputs:
	NONE
� Return: None
 *******************************************************************************/
void recievefunc (void){
	response=UART_getRecUartBuffer();
}

/*******************************************************************************
� Description
       	 -The function Displays password saved message on the LCD
� Inputs:
		-NONE
� Return: None
 *******************************************************************************/
void displayPasswordSaved(){
	LCD_clearScreen();
	LCD_sendString((uint8*)"Password Saved");
	response=0;
}

/*******************************************************************************
� Description
       	 -The function Prints enter password on the screen and gets the password > 3 numbers and if > 3
       	 sends password if not then it doesn't
� Inputs:
		 -NONE
� Return: None
 *******************************************************************************/
void displayMainMessage(){
	LCD_clearScreen();
	LCD_sendString((uint8*)"Enter Password:");
	LCD_moveCursor(2, 0);
	while(*(key+counter-1)!=0){
		*(key+counter)=KEYPAD_getPressedKey();
		LCD_sendCharacter('*');
		counter++;
	}
	*(key+counter)='\0';

	if(strlen(key)<4){
		response=ENTER_PASSWORD;
		counter=0;
	}
	else{
	UART_sendString(key);
	counter=0;

	response=0;
	}
}

/*******************************************************************************
� Description
       	 -The function Prints renter password on the screen and gets the password > 3 numbers and if > 3
       	 sends password if not then it doesn't
� Inputs:
		 -NONE
� Return: None
 *******************************************************************************/
void displayRenterMessage(){
	LCD_clearScreen();
	LCD_sendString((uint8*)"Renter Password:");
	LCD_moveCursor(2, 0);
	while(*(key+counter-1)!=0){
		*(key+counter)=KEYPAD_getPressedKey();
		LCD_sendCharacter('*');
		counter++;

	}
	*(key+counter)='\0';

	UART_sendString(key);
	counter=0;

	response=0;
}

/*******************************************************************************
� Description
       	 -The function Prints enter choice from + or - and sends choice.
� Inputs:
		 -NONE
� Return: None
 *******************************************************************************/
void displayChoice(){
	LCD_clearScreen();
	LCD_sendString((uint8*)"+:Open Door");
	LCD_moveCursor(2, 0);
	LCD_sendString((uint8*)"-:Change Pass");
	choice=KEYPAD_getPressedKey();
	UART_sendByte(choice);
	choice=0;
	response=0;
}

/*******************************************************************************
� Description
       	 -The function Prints That the password is incorrect and tells tarek to stop messing around
� Inputs:
		 -NONE
� Return: None
 *******************************************************************************/
void displayErrorMessage(){
	LCD_clearScreen();
	LCD_sendString((uint8*)"Pass Incorrect");
	LCD_moveCursor(2, 0);
	LCD_sendString((uint8*)"Tarek mathawelsh");
	response=0;
}

/*******************************************************************************
� Description
       	 -The function Prints That the password is incorrect
� Inputs:
		 -NONE
� Return: None
 *******************************************************************************/
void displayWrongPassword(){
	LCD_clearScreen();
	LCD_sendString((uint8*)"Wrong Password!");
	response=0;
}

/*******************************************************************************
� Description
       	 -The function Prints That door is opening
� Inputs:
		 -NONE
� Return: None
 *******************************************************************************/
void displayOpeningCorrect(void){
	LCD_clearScreen();
	LCD_sendString((uint8*)"Opening Door!");
	response=0;
}

/*******************************************************************************
� Description
       	 -The function Prints That door is closing
� Inputs:
		 -NONE
� Return: None
 *******************************************************************************/
void displayClosingCorrect(void){
	LCD_clearScreen();
	LCD_sendString((uint8*)"Closing Door!");
	response=0;
}

/*******************************************************************************
� Description
       	 -The function Prints enter new password ,gets it and sends it if > 3
� Inputs:
		 -NONE
� Return: None
 *******************************************************************************/
void displayNewMessage(void){
		LCD_clearScreen();
		LCD_sendString((uint8*)"Enter NEW Pass");
		LCD_moveCursor(2, 0);
		while(*(key+counter-1)!=0){
			*(key+counter)=KEYPAD_getPressedKey();
			LCD_sendCharacter('*');
			counter++;
		}
		*(key+counter)='\0';
		if(strlen(key)<4){
			response=ENTER_PASSWORD;
			counter=0;
		}
		else{
		UART_sendString(key);
		counter=0;

		response=0;
		}}
int main(void){
	UART_Configuration s_Configuration ={ENABLE,UART_OddParity,UART_8Bits,9600};
	LCD_init();
	UART_SetCallBack_recieveByte(recievefunc);
	UART_init(&s_Configuration);
	SREG_REG|=(1<<7);
	_delay_ms(30);
	UART_sendByte(START_STATE);
	while(1){
		switch (response){
		case ENTER_PASSWORD:
			displayMainMessage();
			break;
		case WRONG_PASSWORD:
			displayWrongPassword();
			break;
		case CHANGE_PASSWORD:
			displayMainMessage();
			break;
		case BUZZ:
			displayErrorMessage();
			break;
		case RENTER:

			displayRenterMessage();
			break;
		case PASSWORD_SAVED:
			displayPasswordSaved();
			break;
		case CHOICE:
			displayChoice();
			break;
		case CORRECT:
			displayOpeningCorrect();
			break;
		case CLOSE:
			displayClosingCorrect();
			break;
		case DOESNT_MATCH:
			response=0;
			LCD_clearScreen();
			LCD_sendString((uint8 *)"MISMATCHING");
			break;
		case ENTER_NEW_PASSWORD:
			displayNewMessage();
			break;
		}
	}


	return 0;
}



