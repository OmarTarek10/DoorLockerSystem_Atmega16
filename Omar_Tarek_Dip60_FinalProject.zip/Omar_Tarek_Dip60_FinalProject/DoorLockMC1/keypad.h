#ifndef KEYPAD_H_
#define KEYPAD_H_

#include "std_types.h"
#include "atmega_16_regs.h"

#define KEYPAD_PORT_ID PORTC_ID
#define KEYPAD_START_ROW PIN0_ID
#define KEYPAD_START_COLUMN PIN4_ID
#define KEYPAD_NUM_ROWS 4
#define KEYPAD_NUM_COLS 4

#define KEYPAD_BUTTON_PRESSED LOGIC_LOW
#define KEYPAD_BUTTON_RELEASED LOGIC_HIGH

uint8 KEYPAD_getPressedKey(void);


#endif /* KEYPAD_H_ */
